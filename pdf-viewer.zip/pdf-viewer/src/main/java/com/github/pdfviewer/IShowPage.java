package com.github.pdfviewer;

import android.graphics.Bitmap;

public interface IShowPage {

    Bitmap showPage(int index);
}
